# SafeB9SInstaller
Safe, simple, user-friendly installer for sighaxed FIRMs

For usage instructions, refer to [Plailect's guide](https://3ds.guide/).

## Credits
* **Normmatt**, for sdmmc.c / sdmmc.h
* **Cha(N)**, **Kane49**, and all other FatFS contributors for FatFS
* **Myria** for the sighax bruteforcer and for finding the sighax (retail&dev) signature
* **SciresM** for dumping boot9, creating boot9strap.firm and for being the first fearless person to test this
* **hedgeberg** for her tireless efforts in dumping the bootrom
* **TuxSH** for FIRM research and useful hints
* **Plailect** for providing the guide and making this accessible to the common user
* **stuckpixel** for his tireless behind-the-scenes work
* **Gelex** for being of great help on countless occasions
* The fine folks on **freenode #Cakey**
* All **[3dbrew.org](https://www.3dbrew.org/wiki/Main_Page) editors**
* Everyone I possibly forgot, if you think you deserve to be mentioned, just contact me!
